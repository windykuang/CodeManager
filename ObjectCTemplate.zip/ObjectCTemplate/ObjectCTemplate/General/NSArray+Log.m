//
//  NSArray+Log.m
//  NSPredictStudy
//
//  Created by whj on 15/9/10.
//  Copyright (c) 2015年 whj. All rights reserved.
//

#import "NSArray+Log.h"

@implementation NSArray (Log)

//%@ 为数组会来调用这个方法
-(NSString *)descriptionWithLocale:(id)locale{
    
    
    NSMutableString *strM = [NSMutableString string];
    [strM appendString:@"["];
    [strM appendString:@" \n"];
    for (id obj in self) {
        [strM appendFormat:@"%@",obj];
        [strM appendString:@"\n"];
    }
    [strM appendString:@"]"];
    return strM;
}


//-(NSString *)description{
//    
//}
@end
