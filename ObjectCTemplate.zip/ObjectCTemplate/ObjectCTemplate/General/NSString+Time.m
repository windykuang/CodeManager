//
//  NSString+Time.m
//  ImFans
//
//  Created by whj on 15/9/14.
//  Copyright (c) 2015年 YFSS. All rights reserved.
//

#import "NSString+Time.h"

#define kTimeInterval 4

@implementation NSString (Time)

-(BOOL)compareWithTimeIntervalString:(NSString *)intervalString{
    BOOL result = NO;
    NSTimeInterval time = [self doubleValue];
    NSTimeInterval timeInterval = [intervalString doubleValue];
    //如果时间间隔大于60 秒
    if((time - timeInterval)>kTimeInterval){
        result = YES;
    }
    return result;
}


@end
