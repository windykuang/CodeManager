//
//  UIImage+Mask.h
//  ImFans
//
//  Created by kuang on 15/11/10.
//  Copyright © 2015年 YFSS. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImage (Mask)
- (UIImage *)maskImage:(UIColor *)maskColor;

@end
