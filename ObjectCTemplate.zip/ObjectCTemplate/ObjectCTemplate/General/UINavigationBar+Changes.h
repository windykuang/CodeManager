//
//  UINavigationBar+Changes.h
//  ImFans
//
//  Created by kuang on 15/8/1.
//  Copyright (c) 2015年 YFSS. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UINavigationBar (Changes)
- (void)im_setBackgroundColor:(UIColor *)backgroundColor;
@end
