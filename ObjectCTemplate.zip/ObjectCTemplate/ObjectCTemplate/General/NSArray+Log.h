//
//  NSArray+Log.h
//  NSPredictStudy
//
//  Created by whj on 15/9/10.
//  Copyright (c) 2015年 whj. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSArray (Log)

@end
