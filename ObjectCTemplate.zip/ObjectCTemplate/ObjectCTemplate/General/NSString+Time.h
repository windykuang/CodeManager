//
//  NSString+Time.h
//  ImFans
//
//  Created by whj on 15/9/14.
//  Copyright (c) 2015年 YFSS. All rights reserved.
//

#import <Foundation/Foundation.h>

/** 用来处理项目中时间方面的处理*/
@interface NSString (Time)

/** 两个 NSTimeInterval 地字符串 比较时间 大小 相差大于 60秒   */
-(BOOL)compareWithTimeIntervalString:(NSString *)intervalString;


@end
