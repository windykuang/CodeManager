//
//  RNavigationController.m
//  ObjectCTemplate
//
//  Created by kuang on 16/5/13.
//  Copyright © 2016年 kuang. All rights reserved.
//

#import "RNavigationController.h"

@implementation RNavigationController
- (void)configNavigationBar
{
    [[UINavigationBar appearance] setTitleTextAttributes:[NSDictionary dictionaryWithObjectsAndKeys:[UIColor whiteColor],NSForegroundColorAttributeName,[UIFont boldSystemFontOfSize:18.0f],NSFontAttributeName,nil]];
    
    //    [[UIBarButtonItem appearance] setTitleTextAttributes:[NSDictionary dictionaryWithObjectsAndKeys:[UIColor whiteColor], NSForegroundColorAttributeName,
    //                                                          [UIFont systemFontOfSize:18],NSFontAttributeName,
    //                                                          nil]
    //                                                forState:UIControlStateNormal];
    //[[UIImageView appearanceWhenContainedIn:[UINavigationBar class], nil] setTintColor:[UIColor whiteColor]];
    
    
    self.navigationBar.tintColor = [UIColor whiteColor];
    [self.navigationBar setBarTintColor:UIColorFromRGB(0xe0483e)];
    self.navigationBar.translucent = NO;
    
}


#pragma mark - AutoRate

-(BOOL)shouldAutorotate {
    return [[self.viewControllers lastObject] shouldAutorotate];
}

-(UIInterfaceOrientationMask)supportedInterfaceOrientations {
    NSUInteger support = [[self.viewControllers lastObject] supportedInterfaceOrientations];
    [self configNavigationBar];
    return support;
}


- (UIInterfaceOrientation)preferredInterfaceOrientationForPresentation {
    if (self && self.viewControllers && self.viewControllers.count == 0) {
        return UIInterfaceOrientationPortrait;
    }
    return [[self.viewControllers lastObject] preferredInterfaceOrientationForPresentation];
}

#pragma mark - StatusBar

-(UIStatusBarStyle) preferredStatusBarStyle
{
    return UIStatusBarStyleLightContent;
}

-(BOOL) prefersStatusBarHidden
{
    return NO;
}



/**
 *  能拦截所有push进来的子控制器
 */
- (void)pushViewController:(UIViewController *)viewController animated:(BOOL)animated
{
    
    if (self.viewControllers.count > 0) { // 如果现在push的不是栈底控制器(最先push进来的那个控制器)
        viewController.hidesBottomBarWhenPushed = YES;
    }
    [super pushViewController:viewController animated:animated];
}

@end
