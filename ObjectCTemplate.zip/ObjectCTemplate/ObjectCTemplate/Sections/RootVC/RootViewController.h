//
//  RootViewController.h
//  ObjectCTemplate
//
//  Created by kuang on 16/5/13.
//  Copyright © 2016年 kuang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RootViewController : UIViewController
/**
 *
 *  @brief  是否允许编辑从 imagepicker 获取的图片
 */
@property (nonatomic, assign) BOOL allowEditPickedImage;

/**
 *
 *  @brief  加入 navs
 */
- (void)loadNavs;

/**
 *
 *  @brief  setup views
 */
- (void)setupViews;

/**
 *
 *  @brief  修改 nav 的 hidden 状态
 *
 *  @param state
 */
- (void)updateNavigationBarHiddenState:(BOOL)state;

/**
 *
 *  @brief  销毁
 */
- (void)deallocVc;

/**
 *
 *  @brief  camera picke image
 *
 *  @param tag default kDefaultImagePickerViewTag
 */
- (void)pickerImageFromCameraWithTag:(NSInteger)tag;

/**
 *
 *  @brief  album pick image
 *
 *  @param tag default kDefaultImagePickerViewTag
 */
- (void)pickerImageFromAlbumWithTag:(NSInteger)tag;

/**
 *
 *  @brief  picked image
 *
 *  @param image pickEdited image instance
 *  @param tag   picker picker view tag ,default kDefaultImagePickerViewTag
 */
- (void)pickEditedImage:(UIImage *)image tag:(NSInteger)tag;

/**
 *
 *  @brief  picked origin image
 *
 *  @param image  原始图片
 *  @param tag
 */
- (void)pickOriginedImage:(UIImage *)image tag:(NSInteger)tag;
@end
