//
//  RNavigationController.h
//  ObjectCTemplate
//
//  Created by kuang on 16/5/13.
//  Copyright © 2016年 kuang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RNavigationController : UINavigationController

@end
