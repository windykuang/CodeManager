//
//  AppDelegate+Sharing.h
//  ObjectCTemplate
//
//  Created by kuang on 16/5/13.
//  Copyright © 2016年 kuang. All rights reserved.
//

#import "AppDelegate.h"

@interface AppDelegate (Sharing)

@end
