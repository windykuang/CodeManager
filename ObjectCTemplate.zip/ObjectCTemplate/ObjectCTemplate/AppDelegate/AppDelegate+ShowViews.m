//
//  AppDelegate+ShowViews.m
//  ObjectCTemplate
//
//  Created by kuang on 16/5/13.
//  Copyright © 2016年 kuang. All rights reserved.
//

#import "AppDelegate+ShowViews.h"

@implementation AppDelegate (ShowViews)

- (void)showLogin
{
//    //如果当前就是 login 界面就不处理了
//    UIViewController *rootViewVc = self.window.rootViewController;
//    if ([rootViewVc isKindOfClass:[NavViewController class]]) {
//        if ([((NavViewController*)rootViewVc).visibleViewController isKindOfClass:[WBLoginViewController class]]) {
//            return;
//        }
//    }
//    
//    WBNavViewController *nav = [[WBNavViewController alloc] init];
//    [nav setViewControllers:@[
//                              [UIManager loginViewController]]];
//    //nav.navigationBarHidden = YES;
//    self.window.rootViewController = nav;
}

@end
