//
//  AppDelegate+HUD.m
//  ObjectCTemplate
//
//  Created by kuang on 16/5/13.
//  Copyright © 2016年 kuang. All rights reserved.
//

#import "AppDelegate+HUD.h"

@implementation AppDelegate (HUD)

#pragma mark - SHOW HUD message

- (MBProgressHUD *)makeHUDAtView:(UIView *)view
                         message:(NSString *)message
                           delay:(NSTimeInterval)delay
{
    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:view animated:YES];
    hud.margin = 10.0;
    hud.cornerRadius = 5.0;
    hud.opacity = 0.5;
    hud.yOffset -= 40;
    
    if (message && ![message isEqualToString:@""]) {
        hud.labelText = message;
        hud.mode = MBProgressHUDModeText;
    }
    if (delay != -1) {
        [hud hide:YES afterDelay:delay];
    }
    return hud;
}

- (void)removeHUD:(MBProgressHUD *)hud delay:(NSTimeInterval)delay
{
    if (hud) {
        [hud hide:YES afterDelay:delay];
        [hud removeFromSuperview];
        hud = nil;
    }
}

- (void)showHUDMessage:(NSString *)message
             hideDelay:(NSTimeInterval)delay
{
    [self removeHUD:self.windownHud delay:0];
    self.windownHud = [self makeHUDAtView:self.window message:message delay:delay];
}

- (void)removeHUDDelay:(NSTimeInterval)delay
{
    [self removeHUD:self.windownHud delay:delay];
}

- (void)showHUDtoView:(UIView *)view
              message:(NSString *)message
            hideDelay:(NSTimeInterval)delay
{
    [self removeHUD:self.viewHud delay:0];
    self.viewHud = [self makeHUDAtView:view message:message delay:delay];
}

- (void)removeHUDFromViewDelay:(NSTimeInterval)delay
{
    [self removeHUD:self.viewHud delay:delay];
}

@end
