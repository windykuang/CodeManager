//
//  AppDelegate+Sharing.m
//  ObjectCTemplate
//
//  Created by kuang on 16/5/13.
//  Copyright © 2016年 kuang. All rights reserved.
//

#import "AppDelegate+Sharing.h"

@implementation AppDelegate (Sharing)

@end
