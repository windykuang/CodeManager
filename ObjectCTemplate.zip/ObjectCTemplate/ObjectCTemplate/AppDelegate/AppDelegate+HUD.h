//
//  AppDelegate+HUD.h
//  ObjectCTemplate
//
//  Created by kuang on 16/5/13.
//  Copyright © 2016年 kuang. All rights reserved.
//

#import "AppDelegate.h"

@interface AppDelegate (HUD)
/**
 *  @brief 显示 HUD 消息 在window
 *
 *  @param message 消息内容
 *  @note message = @"",只有 loading没有文字
 *  @param delay   隐藏延迟时间
 *  @note delay = -1时不隐藏
 */
- (void)showHUDMessage:(NSString *)message hideDelay:(NSTimeInterval)delay;

/**
 *  @brief 去掉 HUD
 *
 *  @param delay  隐藏延迟时间
 */
- (void)removeHUDDelay:(NSTimeInterval)delay;

/**
 *
 *  @brief  显示 HUD 消息,在 view
 *
 *  @param view     某一个 view
 *  @param message  hud 消息
 *  @param delay   隐藏延迟时间
 *  @note delay = -1 不隐藏
 */
- (void)showHUDtoView:(UIView *)view
              message:(NSString *)message
            hideDelay:(NSTimeInterval)delay;

/**
 *
 *  @brief  从 view 上移除 HUD
 *
 *  @param delay  延迟时间
 */
- (void)removeHUDFromViewDelay:(NSTimeInterval)delay;
@end
