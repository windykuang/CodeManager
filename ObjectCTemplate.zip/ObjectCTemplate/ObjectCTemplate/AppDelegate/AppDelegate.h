//
//  AppDelegate.h
//  ObjectCTemplate
//
//  Created by kuang on 16/5/13.
//  Copyright © 2016年 kuang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;
@property (nonatomic, strong) MBProgressHUD *windownHud;
@property (nonatomic, strong) MBProgressHUD *viewHud;

@end

