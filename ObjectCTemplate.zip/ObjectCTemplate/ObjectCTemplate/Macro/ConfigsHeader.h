//
//  ConfigsHeader.h
//  ObjectCTemplate
//
//  Created by kuang on 16/5/13.
//  Copyright © 2016年 kuang. All rights reserved.
//

#ifndef ConfigsHeader_h
#define ConfigsHeader_h
//system version
#define kSystemVersion  [[[UIDevice currentDevice] systemVersion] floatValue]
#define kisSimulator    [[[UIDevice currentDevice] model] isEqualToString:@"iPhone Simulator"]
#define iPhone5 ([UIScreen instancesRespondToSelector:@selector(currentMode)] ? CGSizeEqualToSize(CGSizeMake(640, 1136), [[UIScreen mainScreen] currentMode].size) : NO)
#define kiOS7System         kSystemVersion >= 7.0
#define kiOS6System         kSystemVersion < 7.0
#define kiOS8System         kSystemVersion >= 8.0


#define k4Inch ([UIScreen mainScreen].bounds.size.height == 568.0)
#define k3Inch ([UIScreen mainScreen].bounds.size.height == 480.0)

#define kScreenWidth    [UIScreen mainScreen].bounds.size.width

#define kScreenHeight   [UIScreen mainScreen].bounds.size.height
//是否为iOS7
#define iOS7 ([[UIDevice currentDevice].systemVersion doubleValue] >= 7.0)
//是否为iOS8及以上系统
#define iOS8 ([[UIDevice currentDevice].systemVersion doubleValue] >= 8.0)

/** iOS9 */
#define iOS9 ([[UIDevice currentDevice].systemVersion doubleValue] >= 9.0)

#define OSVersionIsAtLeastiOS7  (floor(NSFoundationVersionNumber) > NSFoundationVersionNumber_iOS_6_1)

#define SuppressPerformSelectorLeakWarning(Stuff) \
do { \
_Pragma("clang diagnostic push") \
_Pragma("clang diagnostic ignored \"-Warc-performSelector-leaks\"") \
Stuff; \
_Pragma("clang diagnostic pop") \
} while (0)

//将数字转为
#define EMOJI_CODE_TO_SYMBOL(x) ((((0x808080F0 | (x & 0x3F000) >> 4) | (x & 0xFC0) << 10) | (x & 0x1C0000) << 18) | (x & 0x3F) << 24);


#define RGBColor(r,g,b,a) [UIColor colorWithRed:(CGFloat)r/0xff green:(CGFloat)g/0xff blue:(CGFloat)b/0xff alpha:a]



#define UIColorFromRGB(rgbValue) [UIColor \
colorWithRed:((float)((rgbValue & 0xFF0000) >> 16))/255.0 \
green:((float)((rgbValue & 0xFF00) >> 8))/255.0 \
blue:((float)(rgbValue & 0xFF))/255.0 alpha:1.0]

#define CustomBlueColor UIColorFromRGB(0x007aff)

/**应用全局颜色 */
#define GlobalBg UIColorFromRGB(0xefeff4)


#pragma mark --- 开发中用来测试UIView等常用颜色的颜色-------
/**黑色*/
#define BlackColor [UIColor blackColor]
/**白色*/
#define WhiteColor [UIColor whiteColor]
/**无色*/
#define ClearColor [UIColor clearColor]

#pragma mark 便捷颜色 color for test 用来Debug 的颜色
/**橙色*/
#define OrangeColor [UIColor orangeColor]
/**紫色*/
#define PurpleColor [UIColor purpleColor]
#define RedColor    [UIColor redColor]
#define WhiteColor  [UIColor whiteColor]
#define GrayColor   [UIColor grayColor]
#define YellowColor   [UIColor yellowColor]
#define GreenColor   [UIColor greenColor]
/**品红,洋红*/
#define MagentaColor   [UIColor magentaColor]
#define BlueColor   [UIColor blueColor]
#define BrownColor   [UIColor brownColor]

/**App 主要红色*/
#define RedMianColor UIColorFromRGB(0xe0483e)
/**随机色*/
#define RandomColor [UIColor colorWithRed:arc4random_uniform(256)/255.0 green:arc4random_uniform(256)/255.0 blue:arc4random_uniform(256)/255.0 alpha:1.0]

#define WINDOW_COLOR [UIColor colorWithRed:0 green:0 blue:0 alpha:0.4]
/** 系统默认的字体*/
#define font(size) [UIFont systemFontOfSize:(size)]

/** 粗体字*/
#define boldFont(size)  [UIFont boldSystemFontOfSize:(size)]

/// 内部版本号[integerValue]
#define kCurrentInnerAppVersion [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleVersion"]

/// 对外版本号
#define kAppVersion [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleShortVersionString"]

/// bundle ID
#define kBundleID   [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleIdentifier"]

//md5 加密 kBundleIDMd5
#define kBundleIDMd5 [kBundleID md5]

/// delegate
#define kApp    [UIApplication sharedApplication]

#define kAppDelegate (AppDelegate *)kApp.delegate


/// 网络是否可用
#define kNetworkIsReached      [AFNetworkReachabilityManager sharedManager].reachable
#define kNewworkNotReadchedMessage [kAppDelegate showHUDMessage:@"😰网络好像有点问题" hideDelay:2.0]

/// device uuid
#define kUUID [[UIDevice currentDevice] identifierForVendor].UUIDString

/// frame make
#define frame(x,y,w,h)  CGRectMake(x, y, w, h)

#endif /* ConfigsHeader_h */
